﻿namespace imc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.lblAltura = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.txtIMC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblExplicacao = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblExplicacao2 = new System.Windows.Forms.Label();
            this.lblExplicacao3 = new System.Windows.Forms.Label();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(33, 50);
            this.txtPeso.Margin = new System.Windows.Forms.Padding(2);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(153, 20);
            this.txtPeso.TabIndex = 0;
            this.txtPeso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPeso_KeyPress);
            this.txtPeso.Validated += new System.EventHandler(this.TxtPeso_Validated);
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(33, 94);
            this.txtAltura.Margin = new System.Windows.Forms.Padding(2);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(153, 20);
            this.txtAltura.TabIndex = 1;
            this.txtAltura.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAltura_KeyPress);
            this.txtAltura.Validated += new System.EventHandler(this.txtAltura_Validated);
            // 
            // lblAltura
            // 
            this.lblAltura.AutoSize = true;
            this.lblAltura.Location = new System.Drawing.Point(33, 79);
            this.lblAltura.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAltura.Name = "lblAltura";
            this.lblAltura.Size = new System.Drawing.Size(34, 13);
            this.lblAltura.TabIndex = 1;
            this.lblAltura.Text = "Altura";
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(33, 35);
            this.lblPeso.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(31, 13);
            this.lblPeso.TabIndex = 1;
            this.lblPeso.Text = "Peso";
            // 
            // txtIMC
            // 
            this.txtIMC.Location = new System.Drawing.Point(33, 137);
            this.txtIMC.Margin = new System.Windows.Forms.Padding(2);
            this.txtIMC.Name = "txtIMC";
            this.txtIMC.ReadOnly = true;
            this.txtIMC.Size = new System.Drawing.Size(153, 20);
            this.txtIMC.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 122);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "IMC";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(207, 128);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(2);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(68, 26);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 6);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Calculadora IMC";
            // 
            // lblExplicacao
            // 
            this.lblExplicacao.Location = new System.Drawing.Point(11, 193);
            this.lblExplicacao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExplicacao.Name = "lblExplicacao";
            this.lblExplicacao.Size = new System.Drawing.Size(337, 26);
            this.lblExplicacao.TabIndex = 3;
            this.lblExplicacao.Text = "*comentario, criei uma função onde sempre que um ponto é digitado ele transforma " +
    "esse ponto em virgola.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 206);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 3;
            // 
            // lblExplicacao2
            // 
            this.lblExplicacao2.Location = new System.Drawing.Point(11, 230);
            this.lblExplicacao2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExplicacao2.Name = "lblExplicacao2";
            this.lblExplicacao2.Size = new System.Drawing.Size(337, 31);
            this.lblExplicacao2.TabIndex = 3;
            this.lblExplicacao2.Text = "Não sei o motivo, mas minha maquina, ao invez de entender o separadorr de decimal" +
    " sendo o \"ponto\", ele entende que é a \"virgola\"";
            // 
            // lblExplicacao3
            // 
            this.lblExplicacao3.Location = new System.Drawing.Point(11, 270);
            this.lblExplicacao3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExplicacao3.Name = "lblExplicacao3";
            this.lblExplicacao3.Size = new System.Drawing.Size(337, 31);
            this.lblExplicacao3.TabIndex = 3;
            this.lblExplicacao3.Text = "Não sei se esse é o padão, mas  caso o programa retorne o resultado 0 ou algo ine" +
    "xperado, esse pode ser o motivo";
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(207, 90);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(2);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(68, 26);
            this.btnFechar.TabIndex = 2;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 329);
            this.Controls.Add(this.lblExplicacao3);
            this.Controls.Add(this.lblExplicacao2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblExplicacao);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblAltura);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIMC);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.txtPeso);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label lblAltura;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.TextBox txtIMC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblExplicacao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblExplicacao2;
        private System.Windows.Forms.Label lblExplicacao3;
        private System.Windows.Forms.Button btnFechar;
    }
}

