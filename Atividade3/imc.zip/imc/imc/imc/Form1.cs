﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Peso invalido");
                txtPeso.Focus();
            }

            if (peso >= 400 || peso <= 0)
            {
                MessageBox.Show("Peso fora dos padrões");
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalida");
                txtAltura.Focus();
            }

            if (altura >= 2.5 || altura <= 0.1)
            {
                MessageBox.Show("Altura fora dos padrões");
                txtAltura.Focus();
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            imc = Math.Round((peso / Math.Pow(altura, 2)), 1);
            txtIMC.Text = imc.ToString();
            mostrarIMC(imc);
        }

        

        private void mostrarIMC(double imc)
        {
            if(imc < 18.5)
                MessageBox.Show("Sua clasificação é: MAGREZA \n Obesidade: 0");
            else if(imc <= 24.9)
                MessageBox.Show("Sua clasificação é: NORMAL \n Obesidade: 0");
            else if (imc <= 29.9)
                MessageBox.Show("Sua clasificação é: SOBREPESO \n Obesidade: 1");
            else if (imc <= 39.9)
                MessageBox.Show("Sua clasificação é: OBESIDADE \n Obesidade: 2");
            else
                MessageBox.Show("Sua clasificação é: OBESIDADE GRAVE \n Obesidade: 3");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtPeso_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.')
                e.KeyChar = ',';
        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '.')
                e.KeyChar = ',';
        }


    }
}
