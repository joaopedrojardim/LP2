﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mksbxNome = new System.Windows.Forms.MaskedTextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.mksbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.mksbxAliINSS = new System.Windows.Forms.MaskedTextBox();
            this.lblAliINSS = new System.Windows.Forms.Label();
            this.mksbxAliIRPF = new System.Windows.Forms.MaskedTextBox();
            this.lblALiIRPF = new System.Windows.Forms.Label();
            this.mksbxDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mksbxDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.mksbxSalFamilia = new System.Windows.Forms.MaskedTextBox();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.mksbxSalLiquido = new System.Windows.Forms.MaskedTextBox();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.nudFilhos = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // mksbxNome
            // 
            this.mksbxNome.Location = new System.Drawing.Point(30, 33);
            this.mksbxNome.Name = "mksbxNome";
            this.mksbxNome.Size = new System.Drawing.Size(437, 23);
            this.mksbxNome.TabIndex = 0;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(30, 15);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(40, 15);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "Nome";
            // 
            // mksbxSalBruto
            // 
            this.mksbxSalBruto.Location = new System.Drawing.Point(30, 95);
            this.mksbxSalBruto.Mask = "00000000,00";
            this.mksbxSalBruto.Name = "mksbxSalBruto";
            this.mksbxSalBruto.Size = new System.Drawing.Size(437, 23);
            this.mksbxSalBruto.TabIndex = 0;
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(30, 77);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(74, 15);
            this.lblSalBruto.TabIndex = 2;
            this.lblSalBruto.Text = "Salario Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(30, 129);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(99, 15);
            this.lblFilhos.TabIndex = 2;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // mksbxAliINSS
            // 
            this.mksbxAliINSS.Location = new System.Drawing.Point(30, 235);
            this.mksbxAliINSS.Name = "mksbxAliINSS";
            this.mksbxAliINSS.ReadOnly = true;
            this.mksbxAliINSS.Size = new System.Drawing.Size(136, 23);
            this.mksbxAliINSS.TabIndex = 0;
            // 
            // lblAliINSS
            // 
            this.lblAliINSS.AutoSize = true;
            this.lblAliINSS.Location = new System.Drawing.Point(30, 217);
            this.lblAliINSS.Name = "lblAliINSS";
            this.lblAliINSS.Size = new System.Drawing.Size(79, 15);
            this.lblAliINSS.TabIndex = 2;
            this.lblAliINSS.Text = "Aliquota INSS";
            // 
            // mksbxAliIRPF
            // 
            this.mksbxAliIRPF.Location = new System.Drawing.Point(30, 291);
            this.mksbxAliIRPF.Name = "mksbxAliIRPF";
            this.mksbxAliIRPF.ReadOnly = true;
            this.mksbxAliIRPF.Size = new System.Drawing.Size(136, 23);
            this.mksbxAliIRPF.TabIndex = 0;
            // 
            // lblALiIRPF
            // 
            this.lblALiIRPF.AutoSize = true;
            this.lblALiIRPF.Location = new System.Drawing.Point(30, 273);
            this.lblALiIRPF.Name = "lblALiIRPF";
            this.lblALiIRPF.Size = new System.Drawing.Size(78, 15);
            this.lblALiIRPF.TabIndex = 2;
            this.lblALiIRPF.Text = "Aliquota IRPF";
            // 
            // mksbxDescINSS
            // 
            this.mksbxDescINSS.Location = new System.Drawing.Point(189, 235);
            this.mksbxDescINSS.Name = "mksbxDescINSS";
            this.mksbxDescINSS.ReadOnly = true;
            this.mksbxDescINSS.Size = new System.Drawing.Size(136, 23);
            this.mksbxDescINSS.TabIndex = 0;
            // 
            // mksbxDescIRPF
            // 
            this.mksbxDescIRPF.Location = new System.Drawing.Point(189, 291);
            this.mksbxDescIRPF.Name = "mksbxDescIRPF";
            this.mksbxDescIRPF.ReadOnly = true;
            this.mksbxDescIRPF.Size = new System.Drawing.Size(136, 23);
            this.mksbxDescIRPF.TabIndex = 0;
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(189, 217);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(84, 15);
            this.lblDescINSS.TabIndex = 2;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(189, 273);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(83, 15);
            this.lblDescIRPF.TabIndex = 2;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // mksbxSalFamilia
            // 
            this.mksbxSalFamilia.Location = new System.Drawing.Point(30, 340);
            this.mksbxSalFamilia.Name = "mksbxSalFamilia";
            this.mksbxSalFamilia.ReadOnly = true;
            this.mksbxSalFamilia.Size = new System.Drawing.Size(136, 23);
            this.mksbxSalFamilia.TabIndex = 0;
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(30, 322);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(83, 15);
            this.lblSalFamilia.TabIndex = 2;
            this.lblSalFamilia.Text = "Salario Familia";
            // 
            // mksbxSalLiquido
            // 
            this.mksbxSalLiquido.Location = new System.Drawing.Point(30, 394);
            this.mksbxSalLiquido.Mask = "00000000,00";
            this.mksbxSalLiquido.Name = "mksbxSalLiquido";
            this.mksbxSalLiquido.ReadOnly = true;
            this.mksbxSalLiquido.Size = new System.Drawing.Size(136, 23);
            this.mksbxSalLiquido.TabIndex = 0;
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(30, 376);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(82, 15);
            this.lblSalLiquido.TabIndex = 2;
            this.lblSalLiquido.Text = "Salario liquido";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(518, 33);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(134, 23);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Verifica desconto";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // nudFilhos
            // 
            this.nudFilhos.Location = new System.Drawing.Point(30, 147);
            this.nudFilhos.Name = "nudFilhos";
            this.nudFilhos.Size = new System.Drawing.Size(119, 23);
            this.nudFilhos.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 493);
            this.Controls.Add(this.nudFilhos);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblALiIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblAliINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.mksbxDescIRPF);
            this.Controls.Add(this.mksbxDescINSS);
            this.Controls.Add(this.mksbxSalLiquido);
            this.Controls.Add(this.mksbxSalFamilia);
            this.Controls.Add(this.mksbxAliIRPF);
            this.Controls.Add(this.mksbxAliINSS);
            this.Controls.Add(this.mksbxSalBruto);
            this.Controls.Add(this.mksbxNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaskedTextBox mksbxNome;
        private Label lblNome;
        private MaskedTextBox mksbxSalBruto;
        private Label lblSalBruto;
        private Label lblFilhos;
        private MaskedTextBox mksbxAliINSS;
        private Label lblAliINSS;
        private MaskedTextBox mksbxAliIRPF;
        private Label lblALiIRPF;
        private MaskedTextBox mksbxDescINSS;
        private MaskedTextBox mksbxDescIRPF;
        private Label lblDescINSS;
        private Label lblDescIRPF;
        private MaskedTextBox mksbxSalFamilia;
        private Label lblSalFamilia;
        private MaskedTextBox mksbxSalLiquido;
        private Label lblSalLiquido;
        private Button btnCalcular;
        private NumericUpDown nudFilhos;
    }
}