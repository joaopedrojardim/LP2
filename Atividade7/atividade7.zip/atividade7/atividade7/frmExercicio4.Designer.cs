﻿namespace atividade7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.texto = new System.Windows.Forms.RichTextBox();
            this.contador = new System.Windows.Forms.Button();
            this.posicao = new System.Windows.Forms.Button();
            this.letras = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // texto
            // 
            this.texto.Location = new System.Drawing.Point(19, 34);
            this.texto.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.texto.Name = "texto";
            this.texto.Size = new System.Drawing.Size(161, 42);
            this.texto.TabIndex = 0;
            this.texto.Text = "";
            // 
            // contador
            // 
            this.contador.Location = new System.Drawing.Point(203, 49);
            this.contador.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contador.Name = "contador";
            this.contador.Size = new System.Drawing.Size(93, 27);
            this.contador.TabIndex = 1;
            this.contador.Text = "Contador";
            this.contador.UseVisualStyleBackColor = true;
            this.contador.Click += new System.EventHandler(this.Button1_Click);
            // 
            // posicao
            // 
            this.posicao.Location = new System.Drawing.Point(300, 49);
            this.posicao.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.posicao.Name = "posicao";
            this.posicao.Size = new System.Drawing.Size(93, 27);
            this.posicao.TabIndex = 2;
            this.posicao.Text = "Branco";
            this.posicao.UseVisualStyleBackColor = true;
            this.posicao.Click += new System.EventHandler(this.Posicao_Click);
            // 
            // letras
            // 
            this.letras.Location = new System.Drawing.Point(397, 49);
            this.letras.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.letras.Name = "letras";
            this.letras.Size = new System.Drawing.Size(93, 27);
            this.letras.TabIndex = 3;
            this.letras.Text = "Letras";
            this.letras.UseVisualStyleBackColor = true;
            this.letras.Click += new System.EventHandler(this.Letras_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Texto:";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.letras);
            this.Controls.Add(this.posicao);
            this.Controls.Add(this.contador);
            this.Controls.Add(this.texto);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox texto;
        private System.Windows.Forms.Button contador;
        private System.Windows.Forms.Button posicao;
        private System.Windows.Forms.Button letras;
        private System.Windows.Forms.Label label1;
    }
}