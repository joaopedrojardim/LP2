﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for (var i = 0; i < texto.Text.Length; i++)
            {
                if (char.IsNumber(texto.Text[i]))
                    contador++;
            }

            MessageBox.Show($"a frase tem {contador} números");

        }

        private void Posicao_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicao = 0;

            while (contador < texto.Text.Length)
            {
                if (char.IsWhiteSpace(texto.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }

                contador += 1;
            }

            MessageBox.Show("O primeiro caracter em branco está na posição " + posicao);

        }

        private void Letras_Click(object sender, EventArgs e)
        {

            int contador = 0;

            foreach (var c in texto.Text)
            {
                if (char.IsLetter(c))
                {
                    contador++;
                }

            }

            MessageBox.Show($"O total de letras na frase : {contador}");


        }
    }
}
