﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade7
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (String.Compare(palavra1.Text, palavra2.Text,true)== 0)
            {
                MessageBox.Show("São iguais");
            }

            else
            {
                MessageBox.Show("São diferentes");
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int metade = palavra2.Text.Length / 2;

            palavra2.Text = palavra2.Text.Substring(0, metade) + palavra1.Text + palavra2.Text.Substring(metade, palavra2.Text.Length-metade);
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int metade = palavra1.Text.Length / 2;

            palavra2.Text = palavra1.Text.Insert(metade, "*");
        }
    }
}
