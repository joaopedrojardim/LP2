﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string auxiliar = "";
            string saida = "";

            for(int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com o numero {i + 1}", "Entrada de dados");
                if (auxiliar == "")
                    return;

                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero invalido");
                    i--; 
                }
                else
                {
                    saida = vetor[i] + "\n" +saida; 
                }
               
            }

            MessageBox.Show(saida);

        }

        private void BtnEx2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[4, 3];

            double media = 0;

            string aux = "";

            for (int lin = 0; lin < 4; lin++)
                for(int col = 0; col < 3; col++)
                {
                    aux = Interaction.InputBox($"Entre com o nota {col + 1} do aluno {lin + 1}", "Notas");

                    if (aux == "")
                        return;
                    if (!double.TryParse(aux, out notas[lin, col]))
                    {
                        MessageBox.Show("Nun é numero");
                        col--;
                    }
                    else
                    {
                        if(notas[lin,col] < 0 || notas[lin, col] > 10)
                        {
                            MessageBox.Show("Numero entre 0 e 10 po favor");
                            col--;
                        }
                    }
                }

            for (int lin = 0; lin < 4; lin++)
            {
                media = 0;
                for (int col = 0; col < 3; col++)
                {
                    media += notas[lin, col];
                    if(col == 2)
                    {
                        media = media / 3;
                        MessageBox.Show($"A media do aluno {lin + 1} é: {media}");
                    }
                }
            }
        }
    }
}
