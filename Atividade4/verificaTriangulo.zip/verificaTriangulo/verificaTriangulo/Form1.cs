﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace verificaTriangulo
{
    public partial class Form1 : Form
    {
        double lado1;
        double lado2;
        double lado3;
        string mensagem;

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtLado1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLado1, "");

            if(!double.TryParse(txtLado1.Text, out lado1))
            {
                errorProvider1.SetError(txtLado1, "Valor do lado 1 inválido");
            }
        }

        private void TxtLado2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtLado2, "");

            if (!double.TryParse(txtLado2.Text, out lado2))
            {
                errorProvider2.SetError(txtLado2, "Valor do lado2 inválido");
            }
        }

        private void TxtLado3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtLado3, "");

            if (!double.TryParse(txtLado3.Text, out lado3))
            {
                errorProvider3.SetError(txtLado3, "Valor do lado 3 inválido");
            }
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if( !double.TryParse(txtLado1.Text, out lado1) ||
                !double.TryParse(txtLado2.Text, out lado2) ||
                !double.TryParse(txtLado3.Text, out lado3)
              )
                MessageBox.Show("Digite números");
            else
                if (Math.Abs(lado2 - lado3) < lado1 && (lado2 + lado3) > lado1 && Math.Abs(lado1 - lado3) < lado2 && (lado1 + lado3) > lado2 && Math.Abs(lado1 - lado2) < lado3 && (lado1 + lado2) > lado3)
                    mostrarTipoTriangulo();
                else
                    MessageBox.Show("Não é um triangulo");

        }

        private void mostrarTipoTriangulo()
        {
            if (lado1 == lado2 && lado2 == lado3)
                mensagem = $"Triangulo Equilatero, lado 1 = {lado1}, lado 2 = {lado2}, lado 3 = {lado3}";
            else if ((lado1 != lado2) && (lado2 != lado3) && (lado1 != lado3))
                mensagem = $"Triangulo Escaleno, lado 1 = {lado1}, lado 2 = {lado2}, lado 3 = {lado3}";
            else
                mensagem = $"Triangulo Isoceles, lado 1 = {lado1}, lado 2 = {lado2}, lado 3 = {lado3}";

            MessageBox.Show(mensagem);
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
