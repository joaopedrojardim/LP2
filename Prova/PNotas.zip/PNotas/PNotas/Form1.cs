﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
            


        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            string[] res = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };
            char[,] alunos = new char[2, 10];

            string aux;

            for(int aluno = 0; aluno < 2; aluno++)
            {
                for (int questao = 0; questao < 10; questao++)
                {
                    aux = Interaction.InputBox($"Digite a resposta da questão {questao + 1} do aluno {aluno + 1}", "Entrada de respostas");

                    if (aux == "")
                        return;

                    if(aux == "A" || aux == "B" || aux == "C" || aux == "D" || aux == "E")
                    {
                        if(aux == res[questao])
                        {
                            lboxNotas.Items.Add($"O aluno {aluno + 1} acertou questão: {questao+ 1} era {res[questao]} e escolheu {aux}");
                        }
                        else
                        {
                            lboxNotas.Items.Add($"O aluno {aluno + 1} errou questão: {questao + 1} era {res[questao]} e escolheu {aux}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("questao invalida");
                        questao--;
                    }
                }
            }
        }
    }
}
