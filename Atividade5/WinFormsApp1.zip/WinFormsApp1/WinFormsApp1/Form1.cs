namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        double salarioBruto;
        double descINSS;
        double descIRPF;
        string aliINSS;
        string aliIRPF;
        double salarioFamilia;
        double salarioLiquido;
        double numeroFilhos;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(double.TryParse(mksbxSalBruto.Text, out salarioBruto))
            {
                salarioBruto /= 100;
                numeroFilhos = (double)nudFilhos.Value;
                calcINSS();
                calcIRPF();
                calcSalFam();
                calcFim();
            }
            else
            {
                MessageBox.Show("Valor Invalido");
            }
        }

        private void calcINSS()
        {
            if(salarioBruto <= 800.47)
            {
                descINSS = salarioBruto * 0.0765;
                aliINSS = "7,65%";
            }else if(salarioBruto <= 1050)
            {
                descINSS = salarioBruto * 0.0865;
                aliINSS = "8,65%";
            }
            else if (salarioBruto <= 1400.77)
            {
                descINSS = salarioBruto * 0.09;
                aliINSS = "9.00%";
            }
            else if (salarioBruto <= 2801.56)
            {
                descINSS = salarioBruto * 0.11;
                aliINSS = "11,00%";
            }
            else
            {
                descINSS = 308.17;
                aliINSS = "TETO";
            }

            mksbxDescINSS.Text = Math.Round(descINSS, 2).ToString();
            mksbxAliINSS.Text = aliINSS;
        }

        private void calcIRPF()
        {
            if(salarioBruto <= 1257.12)
            {
                descIRPF = 0;
                aliIRPF = "Isento";
            }else if(salarioBruto < 2512.08)
            {
                descIRPF = salarioBruto * 0.15;
                aliIRPF = "15.00%";
            }
            else
            {
                descIRPF = salarioBruto * 0.275;
                aliIRPF = "27.5%";
            }

            mksbxDescIRPF.Text = Math.Round(descIRPF, 2).ToString();
            mksbxAliIRPF.Text = aliIRPF;
        }

        private void calcSalFam()
        {
            if (salarioBruto < 435.52)
                salarioFamilia = numeroFilhos * 22.33;
            else if (salarioBruto <= 654.61)
                salarioFamilia = numeroFilhos * 15.74;
            else
                salarioFamilia = 0;

            mksbxSalFamilia.Text = Math.Round(salarioFamilia, 2).ToString();
        }

        private void calcFim()
        {
            salarioLiquido = salarioBruto - descINSS - descIRPF + salarioFamilia;
            mksbxSalLiquido.Text = Math.Round(salarioLiquido, 2).ToString();
        }
    }
}