﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraS
{
    public partial class Form1 : Form
    {
        double numero1;
        double numero2;
        double resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("número inválido");
                txtNumero1.Focus();
            }
        }

        private void TxtNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("número inválido");
                txtNumero2.Focus();
            }
        }

        private void BtnSomar_Click(object sender, EventArgs e)
        {
            if (validaClick())
                txtResultado.Text = Convert.ToString((numero1 + numero2));
        }

        private void BtnSubtrair_Click(object sender, EventArgs e)
        {
            if (validaClick())
                txtResultado.Text = Convert.ToString((numero1 - numero2));
        }

        private void BtnMultiplicar_Click(object sender, EventArgs e)
        {
           if(validaClick())
              txtResultado.Text = Convert.ToString((numero1 * numero2));
        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            if (validaClick())
                if (numero2 == 0)
                    MessageBox.Show("Não pode divisão por 0 né amigo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    txtResultado.Text = Convert.ToString((numero1 / numero2));

                }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Deseja realmente sair?", "Saída",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private bool validaClick()
        {
            if(txtNumero1.Text == "")
            {
                MessageBox.Show("Numero 1 não pode ser vazio");
                txtNumero1.Focus();
                return false;
            }

            if (txtNumero2.Text == "")
            {
                MessageBox.Show("Numero 2 não pode ser vazio");
                txtNumero2.Focus();
                return false;
            }

            return true;
        }
    }
}
