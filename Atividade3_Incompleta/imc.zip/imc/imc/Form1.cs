﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtAltura_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalida");
                txtAltura.Focus();
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            // Math.Round(2.344, 1)
            imc = Math.Round((peso / Math.Pow(altura, 2)), 1);
            // imc = 10;
            txtIMC.Text = imc.ToString();
        }

        private void TxtPeso_Validated(object sender, EventArgs e)
        {
            if(! double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Peso invalido");
                txtPeso.Focus();
            }
        }
    }
}
